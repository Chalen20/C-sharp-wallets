﻿namespace BudgetsWPF.Budgets
{
    public class BudgetsViewModel : IMainNavigatable
    {
        public MainNavigatableTypes Type
        {
            get
            {
                return MainNavigatableTypes.Budgets;
            }
        }

        public void ClearSensitiveData()
        {
        }
    }
}
