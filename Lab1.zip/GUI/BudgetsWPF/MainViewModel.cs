﻿using BudgetsWPF.Authentication;
using BudgetsWPF.Budgets;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BudgetsWPF
{
    public class MainViewModel : BindableBase
    {
        private List<IMainNavigatable> _viewModels = new List<IMainNavigatable>();
        private Action _signInSuccess;

        public IMainNavigatable CurrentViewModel
        {
            get;
            private set;
        }
        public MainViewModel(Action SignInSuccess)
        {
            _signInSuccess = SignInSuccess;
            Navigate(MainNavigatableTypes.Auth);
        }

        public void Navigate(MainNavigatableTypes type)
        {
            if (CurrentViewModel != null && CurrentViewModel.Type == type)
                return;
            IMainNavigatable viewModel = _viewModels.FirstOrDefault(authNavigatable => authNavigatable.Type == type);
            /* foreach (var authNavigatable in _viewModels)
            {
                if (authNavigatable.Type == type)
                {
                    viewModel = authNavigatable;
                    break;
                }
            }*/
            if (viewModel == null)
            {
                viewModel = CreateViewModel(type);   
                _viewModels.Add(viewModel);
            }
            viewModel.ClearSensitiveData();
            CurrentViewModel = viewModel;
            RaisePropertyChanged(nameof(CurrentViewModel));
        }

        private IMainNavigatable CreateViewModel(MainNavigatableTypes type)
        {
            if (type == MainNavigatableTypes.Auth)
            {
                return new AuthViewModel(() => Navigate(MainNavigatableTypes.Budgets));
            }
            else /*if (type == AuthNavigatableTypes.SignUp)*/
            {
                return new BudgetsViewModel();
            }
        }
    }
}
