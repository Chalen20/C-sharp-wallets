﻿using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BudgetsWPF.Authentication
{
    public class AuthViewModel : BindableBase, IMainNavigatable
    {
        private List<IAuthNavigatable> _viewModels = new List<IAuthNavigatable>();
        private Action _signInSuccess;

        public IAuthNavigatable CurrentViewModel
        {
            get;
            private set;
        }

        public MainNavigatableTypes Type
        {
            get
            {
                return MainNavigatableTypes.Auth;
            }
        }

        public AuthViewModel(Action SignInSuccess)
        {
            _signInSuccess = SignInSuccess;
            Navigate(AuthNavigatableTypes.SignIn);
        }

        public void Navigate(AuthNavigatableTypes type)
        {
            if (CurrentViewModel != null && CurrentViewModel.Type == type)
                return;
            IAuthNavigatable viewModel = _viewModels.FirstOrDefault(authNavigatable => authNavigatable.Type == type);
            /* foreach (var authNavigatable in _viewModels)
            {
                if (authNavigatable.Type == type)
                {
                    viewModel = authNavigatable;
                    break;
                }
            }*/
            if (viewModel == null)
            {
                viewModel = CreateViewModel(type);   
                _viewModels.Add(viewModel);
            }
            viewModel.ClearSensitiveData();
            CurrentViewModel = viewModel;
            RaisePropertyChanged(nameof(CurrentViewModel));
        }

        private IAuthNavigatable CreateViewModel(AuthNavigatableTypes type)
        {
            if (type == AuthNavigatableTypes.SignIn)
            {
                return new SignInViewModel(() => Navigate(AuthNavigatableTypes.SignUp), _signInSuccess);
            }
            else /*if (type == AuthNavigatableTypes.SignUp)*/
            {
                return new SignUpViewModel(() => Navigate(AuthNavigatableTypes.SignIn));
            }
        }

        public void ClearSensitiveData()
        {
            CurrentViewModel.ClearSensitiveData();
        }
    }
}
