﻿using System.Windows.Controls;

namespace BudgetsWPF.Authentication
{
    /// <summary>
    /// Логика взаимодействия для AuthView.xaml
    /// </summary>
    public partial class AuthView : UserControl
    {
        public AuthView()
        {
            InitializeComponent();
        }
    }
}
