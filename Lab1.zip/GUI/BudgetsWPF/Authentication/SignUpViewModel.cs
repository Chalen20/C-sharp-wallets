﻿using Prism.Commands;
using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;

namespace BudgetsWPF.Authentication
{
    public class SignUpViewModel : INotifyPropertyChanged, IAuthNavigatable
    {
        private RegistrationUser _regUser = new RegistrationUser();

        public event PropertyChangedEventHandler PropertyChanged;

        private Action _goToSignIn;

        public string Login 
        {
            get 
            {
                return _regUser.Login;
            }
            set 
            {
                if (_regUser.Login != value)
                {
                    _regUser.Login = value;
                    OnPropertyChanged(); //nameof(Login));
                    SignUpCommand.RaiseCanExecuteChanged();
                }
            }
        }

        public string Password 
        {
            get
            {
                return _regUser.Password;
            }
            set 
            {
                if (_regUser.Password != value)
                {
                    _regUser.Password = value;
                    OnPropertyChanged(); //nameof(Password));
                    SignUpCommand.RaiseCanExecuteChanged();
                }
            }
        }

        public string FirstName
        {
            get
            {
                return _regUser.FirstName;
            }
            set
            {
                if (_regUser.FirstName != value)
                {
                    _regUser.FirstName = value;
                    OnPropertyChanged(); //nameof(FirstName));
                    SignUpCommand.RaiseCanExecuteChanged();
                }
            }
        }

        public string LastName
        {
            get
            {
                return _regUser.LastName;
            }
            set
            {
                if (_regUser.LastName != value)
                {
                    _regUser.LastName = value;
                    OnPropertyChanged(); //nameof(LastName));
                    SignUpCommand.RaiseCanExecuteChanged();
                }
            }
        }

        public string Email
        {
            get
            {
                return _regUser.Email;
            }
            set
            {
                if (_regUser.Email != value)
                {
                    _regUser.Email = value;
                    OnPropertyChanged(); //nameof(Email));
                    SignUpCommand.RaiseCanExecuteChanged();
                }
            }
        }

        public DelegateCommand SignUpCommand { get; }
        public DelegateCommand CloseCommand { get; }
        public DelegateCommand SignInCommand { get; }

        public AuthNavigatableTypes Type
        {
            get
            {
                return AuthNavigatableTypes.SignUp;
            }
        }
        public SignUpViewModel(Action GoToSignIn) 
        {
            SignUpCommand = new DelegateCommand(SignUp, IsSignUpEnabled);
            CloseCommand = new DelegateCommand(() => Environment.Exit(0));
            _goToSignIn = GoToSignIn;
            SignInCommand = new DelegateCommand(_goToSignIn);
        }

        private bool IsSignUpEnabled()
        {
            return (!String.IsNullOrWhiteSpace(Login) && (!String.IsNullOrWhiteSpace(Password)));
        }

        private void SignUp()
        {
            var authService = new AuthenticationService();
            try
            {
                authService.RegisterUser(_regUser);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Sign in failed: {ex.Message}");
                return;
            }
            MessageBox.Show($"User successfully registered, please Sign In.");
            _goToSignIn.Invoke();
        }

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public void ClearSensitiveData()
        {
            _regUser = new RegistrationUser();
        }
    }
}
