﻿namespace BudgetsWPF
{
    public enum MainNavigatableTypes
    {
        Auth,
        Budgets
    }
    public interface IMainNavigatable
    {
        public MainNavigatableTypes Type { get; }

        public void ClearSensitiveData();
    }
}
