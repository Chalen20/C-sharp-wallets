﻿namespace BudgetsWPF
{
    public class AuthenticationUser
    {
        public string Login { get; set; }
        public string Password { get; set; }
    }
}
