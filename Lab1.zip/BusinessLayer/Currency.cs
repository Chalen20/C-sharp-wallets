﻿namespace BusinessLayer
{
    public enum Currency
    {
        UAH,
        USD,
        EUR,
    }
}
